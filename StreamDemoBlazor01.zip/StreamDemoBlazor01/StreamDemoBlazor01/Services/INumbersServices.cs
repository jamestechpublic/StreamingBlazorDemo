﻿using StreamDemoBlazor01.Api.Models;
using System.Runtime.CompilerServices;

namespace StreamDemoBlazor01.Services
{
    public interface INumbersServices
    {
        IAsyncEnumerable<RandomNumber> StreamNumbersAsync(
            [EnumeratorCancellation] CancellationToken cancellationToken);
    }
}
