﻿using StreamDemoBlazor01.Api.Models;
using System.Runtime.CompilerServices;
using System.Text.Json;

namespace StreamDemoBlazor01.Services
{
    public class NumbersServices(HttpClient _httpClient) : INumbersServices
    {
        public async IAsyncEnumerable<RandomNumber> StreamNumbersAsync(
            [EnumeratorCancellation] CancellationToken cancellationToken)
        {
            var response = await _httpClient.GetAsync("api/randomnumbers/stream",
                                        HttpCompletionOption.ResponseHeadersRead, cancellationToken);

            response.EnsureSuccessStatusCode();

            using var stream = await response.Content.ReadAsStreamAsync(cancellationToken);
            using var reader = new StreamReader(stream);

            while (!reader.EndOfStream && !cancellationToken.IsCancellationRequested)
            {
                var line = await reader.ReadLineAsync();
                if (!string.IsNullOrWhiteSpace(line))
                {
                    var number = JsonSerializer.Deserialize<RandomNumber>(line);
                    if (number is not null)
                        yield return number;
                }
            }
        }
    }
}



//var request = new HttpRequestMessage(HttpMethod.Get, "api/randomnumbers/stream");
//using var response = await _httpClient.SendAsync(request, HttpCompletionOption.ResponseHeadersRead, cancellationToken);
//response.EnsureSuccessStatusCode();

//var stream = await response.Content.ReadAsStreamAsync(cancellationToken);
//using var reader = new StreamReader(stream);

//while (!reader.EndOfStream)
//{
//    var line = await reader.ReadLineAsync();
//    if (!string.IsNullOrWhiteSpace(line))
//    {
//        var number = JsonSerializer.Deserialize<RandomNumber>(line);
//        if (number is not null)
//            yield return number;
//    }
//}