﻿using Microsoft.AspNetCore.Mvc;
using StreamDemoBlazor01.Api.Repository;
using System.Runtime.CompilerServices;
using System.Text.Json;

namespace StreamDemoBlazor01.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RandomNumbersController(IDataAccess dataAccess) : ControllerBase
    {
        [HttpGet("stream")]
        public async Task StreamRandomNumbers([EnumeratorCancellation] CancellationToken cancellationToken)
        {
            Response.ContentType = "application/x-ndjson";

            await foreach (var record in dataAccess.StreamAllAsync(cancellationToken))
            {
                //yield return record;
                var json = JsonSerializer.Serialize(record);
                await Response.WriteAsync(json + "\n", cancellationToken);
                await Response.Body.FlushAsync(cancellationToken); // Push each line immediately

            }
        }
    }
}
