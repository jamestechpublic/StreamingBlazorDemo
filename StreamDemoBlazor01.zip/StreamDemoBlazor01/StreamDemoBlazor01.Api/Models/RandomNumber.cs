﻿namespace StreamDemoBlazor01.Api.Models
{
    public class RandomNumber
    {
        public int Id { get; set; }
        public int RandomValue { get; set; }
    }
}
