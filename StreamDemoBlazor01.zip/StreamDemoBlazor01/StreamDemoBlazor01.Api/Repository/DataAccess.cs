﻿using Microsoft.Data.Sqlite;
using StreamDemoBlazor01.Api.Models;
using System.Runtime.CompilerServices;

namespace StreamDemoBlazor01.Api.Repository
{
    public class DataAccess(string _connectionString) : IDataAccess
    {
        public async IAsyncEnumerable<RandomNumber> StreamAllAsync(
            [EnumeratorCancellation] CancellationToken cancellationToken)
        {
            await using var con = new SqliteConnection(_connectionString);
            await con.OpenAsync(cancellationToken);

            var cmd = new SqliteCommand("SELECT Id, RandomValue FROM RandomNumbers", con);
            await using var reader = await cmd.ExecuteReaderAsync(cancellationToken);

            while (await reader.ReadAsync(cancellationToken))
            {
                yield return new RandomNumber
                {
                    Id = reader.GetInt32(0),
                    RandomValue = reader.GetInt32(1)
                };
            }
        }

    }
}
