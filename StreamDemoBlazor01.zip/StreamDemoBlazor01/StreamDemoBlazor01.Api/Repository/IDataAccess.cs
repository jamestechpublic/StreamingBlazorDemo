﻿using StreamDemoBlazor01.Api.Models;
using System.Runtime.CompilerServices;

namespace StreamDemoBlazor01.Api.Repository
{
    public interface IDataAccess
    {
        IAsyncEnumerable<RandomNumber> StreamAllAsync(
            [EnumeratorCancellation] CancellationToken cancellationToken);
    }
}
